from PySide6.QtWidgets import *
from PySide6.QtCore import Qt

from node import HanziNode
from database import PRIMITIVES
from renderer import HanziRenderer
from primitive_list import PrimitiveList
from project import Project
from history import History

class MainWindow(QWidget):

    def __init__(self):
        super().__init__()
        self.currentNode = None
        self.leftNode = None
        self.rightNode = None
        self.setWindowTitle("Hanzi Builder")
        self.resize(800, 600)
        self.history = History()
        layout = QVBoxLayout()
        # 제목
        title = QLabel("한자 조립기")
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("font-size:25px;")

        layout.addWidget(title)
        # 작업 영역
        workArea = QHBoxLayout()

        # 기초자 목록
        self.primitiveList = PrimitiveList()

        # 렌더러
        self.renderer = HanziRenderer()

        # 왼쪽: 기초자 / 오른쪽: 렌더러
        workArea.addWidget(self.primitiveList)
        workArea.addWidget(self.renderer)

        layout.addLayout(workArea)

        # 1번째 줄
        row1 = QHBoxLayout()

        self.mode = QComboBox()

        self.mode.addItems(["左右","上下"])

        self.combo = QComboBox()

        self.combo.addItems(PRIMITIVES)

        row1.addWidget(QLabel("배치 방식"))

        row1.addWidget(self.mode)

        row1.addWidget(QLabel("기초자"))

        row1.addWidget(self.combo)

        layout.addLayout(row1)

        # 버튼
        row2 = QHBoxLayout()

        primitiveBtn = QPushButton("기초자 선택")
        leftBtn = QPushButton("왼쪽 넣기")
        rightBtn = QPushButton("오른쪽 넣기")
        composeBtn = QPushButton("조립")
        saveBtn = QPushButton("저장")
        loadBtn = QPushButton("불러오기")
        newBtn = QPushButton("새 프로젝트")

        primitiveBtn.clicked.connect(
            self.pickPrimitive
        )

        leftBtn.clicked.connect(
            self.putLeft
        )

        rightBtn.clicked.connect(
            self.putRight
        )
        saveBtn.clicked.connect(self.saveProject)
        loadBtn.clicked.connect(self.loadProject)
        newBtn.clicked.connect(self.newProject)

        composeBtn.clicked.connect(self.compose)

        row2.addWidget(primitiveBtn)

        row2.addWidget(leftBtn)

        row2.addWidget(rightBtn)

        row2.addWidget(composeBtn)
        row2.addWidget(newBtn)
        row2.addWidget(saveBtn)
        row2.addWidget(loadBtn)

        layout.addLayout(row2)

        # 좌우 슬롯
        row3 = QHBoxLayout()

        row3.addWidget(
            QLabel("왼쪽")
        )

        self.leftLabel = QLabel("□")

        self.leftLabel.setAlignment(
            Qt.AlignCenter
        )

        row3.addWidget(
            self.leftLabel
        )

        row3.addSpacing(40)

        row3.addWidget(
            QLabel("오른쪽")
        )

        self.rightLabel = QLabel("□")

        self.rightLabel.setAlignment(
            Qt.AlignCenter
        )

        row3.addWidget(
            self.rightLabel
        )

        layout.addLayout(row3)

        # 정보
        self.info = QLabel(
            "현재 글자가 없습니다."
        )

        layout.addWidget(self.info)

        self.setLayout(layout)


    def pickPrimitive(self):

        value = self.combo.currentText()

        self.currentNode = HanziNode(
            primitive=value
        )

        self.renderer.setNode(
            self.currentNode
        )

        self.info.setText(
            f"현재 글자 : {value}"
        )


    def putLeft(self):

        if self.currentNode is not None:

            self.leftNode = self.currentNode

            self.leftLabel.setText(
                "★"
            )

        else:

            value = self.combo.currentText()

            self.leftNode = HanziNode(
                primitive=value
            )

            self.leftLabel.setText(
                value
            )


    def putRight(self):

        if self.currentNode is not None:

            self.rightNode = self.currentNode

            self.rightLabel.setText(
                "★"
            )

        else:

            value = self.combo.currentText()

            self.rightNode = HanziNode(
                primitive=value
            )

            self.rightLabel.setText(
                value
            )


    def compose(self):

        if self.leftNode is None:

            return

        if self.rightNode is None:

            return

        node = HanziNode()

        node.mode = self.mode.currentText()

        node.left = self.leftNode

        node.right = self.rightNode

        self.currentNode = node

        # 렌더러에 새로운 구조 전달
        self.renderer.setNode(
            self.currentNode
        )

        # 콘솔에 트리 출력
        print(
            self.dump(
                self.currentNode
            )
        )

        # 슬롯 초기화
        self.leftNode = None
        self.rightNode = None
        self.leftLabel.setText("□")
        self.rightLabel.setText("□")
        self.info.setText("새로운 조합이 만들어졌습니다.")


    def dump(self, node, depth=0):

        if node is None:
            return ""

        if node.primitive is not None:
            return ("  " * depth+ node.primitive+ "\n")

        text = ("  " * depth+node.mode+"\n")

        text += self.dump(node.left,depth + 1)

        text += self.dump(node.right,depth + 1)

        return text

    def newProject(self):
        self.history.save(
            self.renderer.nodes
        )
        self.renderer.nodes.clear()

        self.renderer.selectedNode = None

        self.renderer.update()

    def saveProject(self):

        filename, _ = QFileDialog.getSaveFileName(
            self,
            "저장",
            "",
            "Hanzi (*.hanzi)"
        )

        if filename == "":
            return

        Project.save(
            filename,
            self.renderer.nodes
        )

    def loadProject(self):
        self.history.save(self.renderer.nodes)

        filename, _ = QFileDialog.getOpenFileName(
            self,
            "불러오기",
            "",
            "Hanzi (*.hanzi)"
        )

        if filename == "":
            return

        self.renderer.nodes = Project.load(filename)
        self.renderer.selectedNode = None
        self.renderer.update()

    def undo(self):

        self.renderer.nodes = \
            self.history.undo(
                self.renderer.nodes
            )

        self.renderer.update()

    def redo(self):

        self.renderer.nodes = \
            self.history.redo(
                self.renderer.nodes
            )

        self.renderer.update()

    def keyPressEvent(self, event):

        if (
                event.modifiers() == Qt.ControlModifier
                and event.key() == Qt.Key_Z
        ):
            self.undo()

        elif (
                event.modifiers() == Qt.ControlModifier
                and event.key() == Qt.Key_Y
        ):
            self.redo()
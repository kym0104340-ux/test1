import os

from PySide6.QtWidgets import QWidget
from PySide6.QtGui import QPainter, QPen
from PySide6.QtCore import Qt, QRectF
from PySide6.QtSvg import QSvgRenderer

from node import HanziNode


class HanziRenderer(QWidget):

    def __init__(self, parent=None):
        super().__init__(parent)
        self.nodes = []
        self.selectedNode = None
        self.svgPath = "svg"
        self.setMinimumSize(500, 500)
        self.setAcceptDrops(True)
        self.dragging = False
        self.dragOffsetX = 0
        self.dragOffsetY = 0
    # 노드 추가
    def addNode(self, node):
        self.nodes.append(node)
        self.update()

    # 기존 코드와 호환
    def setNode(self, node):
        self.addNode(node)

    # ----------------------------
    # 화면 그리기
    # ----------------------------

    def paintEvent(self, event):

        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        if not self.nodes:

            painter.drawText(
                self.rect(),
                Qt.AlignCenter,
                "□"
            )

            painter.end()
            return

        for node in self.nodes:

            self.drawNode(
                painter,
                node,
                node.x,
                node.y,
                node.width,
                node.height
            )

            # 선택 표시
            if node.selected:

                painter.setPen(QPen(Qt.blue, 2))

                painter.drawRect(
                    QRectF(
                        node.x,
                        node.y,
                        node.width,
                        node.height
                    )
                )

        painter.end()

    # ----------------------------
    # 재귀 렌더링
    # ----------------------------

    def drawNode(
            self,
            painter,
            node,
            x,
            y,
            width,
            height
    ):

        if node is None:
            return

        # 기초자

        if node.primitive is not None:

            self.drawPrimitive(
                painter,
                node.primitive,
                x,
                y,
                width,
                height
            )

            return

        # 좌우

        if node.mode == "左右":

            half = width / 2

            self.drawNode(
                painter,
                node.left,
                x,
                y,
                half,
                height
            )

            self.drawNode(
                painter,
                node.right,
                x + half,
                y,
                half,
                height
            )

        # 상하

        elif node.mode == "上下":

            half = height / 2

            self.drawNode(
                painter,
                node.left,
                x,
                y,
                width,
                half
            )

            self.drawNode(
                painter,
                node.right,
                x,
                y + half,
                width,
                half
            )

    # ----------------------------
    # SVG 출력
    # ----------------------------

    def drawPrimitive(
            self,
            painter,
            primitive,
            x,
            y,
            width,
            height
    ):

        filename = os.path.join(
            self.svgPath,
            primitive + ".svg"
        )

        if not os.path.exists(filename):

            painter.drawText(
                QRectF(x, y, width, height),
                Qt.AlignCenter,
                primitive
            )

            return

        renderer = QSvgRenderer(filename)

        if not renderer.isValid():

            painter.drawText(
                QRectF(x, y, width, height),
                Qt.AlignCenter,
                primitive
            )

            return

        renderer.render(
            painter,
            QRectF(
                x,
                y,
                width,
                height
            )
        )

    # ----------------------------
    # Drag & Drop
    # ----------------------------

    def dragEnterEvent(self, event):

        if event.mimeData().hasText():

            event.acceptProposedAction()

        else:

            event.ignore()

    def dropEvent(self, event):
        self.parent().history.save(self.nodes)
        primitive = event.mimeData().text()

        node = HanziNode(primitive=primitive)

        pos = event.position()

        node.x = pos.x()
        node.y = pos.y()

        self.addNode(node)

        event.acceptProposedAction()

    # ----------------------------
    # 선택
    # ----------------------------
    def mousePressEvent(self, event):

        self.selectedNode = None

        for node in reversed(self.nodes):

            node.selected = False

            if (
                    node.x <= event.position().x() <= node.x + node.width
                    and
                    node.y <= event.position().y() <= node.y + node.height
            ):
                node.selected = True
                self.selectedNode = node

                self.dragging = True

                self.dragOffsetX = event.position().x() - node.x
                self.dragOffsetY = event.position().y() - node.y

                break

        self.update()

    def mouseMoveEvent(self, event):

        if self.dragging and self.selectedNode:
            self.selectedNode.x = (
                    event.position().x()
                    - self.dragOffsetX
            )

            self.selectedNode.y = (
                    event.position().y()
                    - self.dragOffsetY
            )

            self.update()

    def mouseReleaseEvent(self, event):
        self.dragging = False

        if self.selectedNode is None:
            return

        other = self.findNearbyNode(
            self.selectedNode
        )

        if other:
            self.parent().history.save(self.nodes)
            newNode = self.composeNodes(
                other,
                self.selectedNode
            )
            self.nodes.remove(other)
            self.nodes.remove(self.selectedNode)
            self.selectedNode = None
            self.addNode(newNode)

        self.update()

    def findNearbyNode(self, node):
        for other in self.nodes:
            if other is node:
                continue

            dx = node.x - other.x
            dy = node.y - other.y

            distance = (dx * dx + dy * dy) ** 0.5

            if distance < 80:
                return other

        return None

    def composeNodes(self, left, right):
        node = HanziNode()
        dx = abs(left.x - right.x)
        dy = abs(left.y - right.y)
        if dx >= dy:
            node.mode = "左右"
            if left.x <= right.x:
                node.left = left
                node.right = right
            else:
                node.left = right
                node.right = left
        else:
            node.mode = "上下"
            if left.x <= right.x:
                node.left = left
                node.right = right
            else:
                node.left = right
                node.right = left
        node.left = left
        node.right = right
        node.x = min(left.x, right.x)
        node.y = min(left.y, right.y)

        return node
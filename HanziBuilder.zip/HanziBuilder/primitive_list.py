from PySide6.QtWidgets import QListWidget, QListWidgetItem
from PySide6.QtCore import Qt, QMimeData
from PySide6.QtGui import QDrag

from database import PRIMITIVES


class PrimitiveList(QListWidget):

    def __init__(self, parent=None):

        super().__init__(parent)

        self.setDragEnabled(True)

        for primitive in PRIMITIVES:

            item = QListWidgetItem(primitive)

            item.setTextAlignment(
                Qt.AlignCenter
            )

            self.addItem(item)


    def startDrag(self, supportedActions):

        item = self.currentItem()

        if item is None:
            return

        mimeData = QMimeData()

        mimeData.setText(
            item.text()
        )

        drag = QDrag(self)

        drag.setMimeData(
            mimeData
        )

        drag.exec(
            Qt.CopyAction
        )
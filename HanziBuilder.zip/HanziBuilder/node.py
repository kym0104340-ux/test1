class HanziNode:

    def __init__(
        self,
        primitive=None
    ):

        self.primitive = primitive
        self.mode = None
        self.left = None
        self.right = None

        self.x = 0
        self.y = 0

        self.width = 120
        self.height = 120

        self.selected = False

    def isPrimitive(self):

        return self.primitive is not None

    def __str__(self):

        if self.isPrimitive():
            return self.primitive

        return f"{self.mode}"
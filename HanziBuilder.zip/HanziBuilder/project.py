import json

from node import HanziNode


class Project:

    @staticmethod
    def save(filename, nodes):

        data = []

        for node in nodes:
            data.append(
                Project.nodeToDict(node)
            )

        with open(
            filename,
            "w",
            encoding="utf-8"
        ) as f:

            json.dump(
                data,
                f,
                ensure_ascii=False,
                indent=4
            )

    @staticmethod
    def load(filename):

        with open(
            filename,
            "r",
            encoding="utf-8"
        ) as f:

            data = json.load(f)

        nodes = []

        for item in data:
            nodes.append(
                Project.dictToNode(item)
            )

        return nodes

    @staticmethod
    def nodeToDict(node):

        if node is None:
            return None

        return {

            "primitive": node.primitive,

            "mode": node.mode,

            "x": node.x,
            "y": node.y,

            "width": node.width,
            "height": node.height,

            "left":
                Project.nodeToDict(node.left),

            "right":
                Project.nodeToDict(node.right)
        }

    @staticmethod
    def dictToNode(data):

        if data is None:
            return None

        node = HanziNode(
            primitive=data["primitive"]
        )

        node.mode = data["mode"]

        node.x = data["x"]
        node.y = data["y"]

        node.width = data["width"]
        node.height = data["height"]

        node.left = Project.dictToNode(
            data["left"]
        )

        node.right = Project.dictToNode(
            data["right"]
        )

        return node
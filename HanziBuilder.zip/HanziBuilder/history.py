import copy


class History:

    def __init__(self):

        self.undoStack = []
        self.redoStack = []

    def save(self, nodes):

        self.undoStack.append(
            copy.deepcopy(nodes)
        )

        self.redoStack.clear()

    def undo(self, nodes):

        if len(self.undoStack) == 0:
            return nodes

        self.redoStack.append(
            copy.deepcopy(nodes)
        )

        return self.undoStack.pop()

    def redo(self, nodes):

        if len(self.redoStack) == 0:
            return nodes

        self.undoStack.append(
            copy.deepcopy(nodes)
        )

        return self.redoStack.pop()